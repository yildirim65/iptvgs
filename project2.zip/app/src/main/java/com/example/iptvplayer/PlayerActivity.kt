package com.example.iptvplayer

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var btnResize: ImageButton

    // Ekran modlari: Sigdir -> Doldur -> Yakinlastir
    private val modlar = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Sigdir",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Doldur (Tam Ekran)",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Yakinlastir"
    )
    private var modIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        supportActionBar?.hide()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerView = findViewById(R.id.player_view)
        btnResize = findViewById(R.id.btn_resize)

        btnResize.setOnClickListener {
            modIndex = (modIndex + 1) % modlar.size
            val (mod, ad) = modlar[modIndex]
            playerView.resizeMode = mod
            Toast.makeText(this, "Ekran: $ad", Toast.LENGTH_SHORT).show()
        }

        val streamUrl = intent.getStringExtra("STREAM_URL")
        if (streamUrl == null) { finish(); return }
        initPlayer(streamUrl)
    }

    private fun initPlayer(url: String) {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        // Universal: m3u8 ise HLS, degilse (ts/mp4 vb.) dogrudan oynat
        val hlsMi = url.substringBefore("?").endsWith(".m3u8") ||
            url.contains(".m3u8")

        val mediaSource = if (hlsMi) {
            val item = MediaItem.Builder()
                .setUri(url)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build()
            HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(item)
        } else {
            ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(url))
        }

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaSource(mediaSource)
            exo.playWhenReady = true
            exo.prepare()

            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(
                        this@PlayerActivity,
                        "Yayin acilamadi: ${error.errorCodeName}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
        }
    }

    // ---------- PENCERE ICINDE IZLEME (PiP) ----------

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) &&
            player?.isPlaying == true
        ) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
        btnResize.visibility =
            if (isInPictureInPictureMode) android.view.View.GONE
            else android.view.View.VISIBLE
    }

    override fun onStop() {
        super.onStop()
        if (Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode) return
        player?.release()
        player = null
    }
}
