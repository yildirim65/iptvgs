package com.example.iptvplayer

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val adapter = ChannelAdapter { channel ->
        oynat(channel.url, channel.name)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recycler_channels)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        aktifListeyiYukle()
    }

    // ---------- MENU ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_playlists -> listelerimDialog()
            R.id.action_add -> yeniListeDialog()
            R.id.action_play_url -> linkOynatDialog()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------- LISTE YONETIMI ----------

    private fun aktifListeyiYukle() {
        val listeler = PlaylistStore.getAll(this)
        if (listeler.isEmpty()) {
            yeniListeDialog()
            return
        }
        val i = PlaylistStore.getActive(this).coerceIn(0, listeler.size - 1)
        val liste = listeler[i]
        title = liste.name
        playlistIndir(liste.m3uUrl())
    }

    private fun listelerimDialog() {
        val listeler = PlaylistStore.getAll(this)
        if (listeler.isEmpty()) { yeniListeDialog(); return }

        val aktif = PlaylistStore.getActive(this)
        val adlar = listeler.mapIndexed { i, p ->
            (if (i == aktif) "▶ " else "") + p.name +
                (if (p.type == "xtream") "  (Xtream)" else "")
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Listelerim")
            .setItems(adlar) { _, secilen ->
                PlaylistStore.setActive(this, secilen)
                aktifListeyiYukle()
            }
            .setPositiveButton("Yeni Ekle") { _, _ -> yeniListeDialog() }
            .setNeutralButton("Sil...") { _, _ -> listeSilDialog() }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun listeSilDialog() {
        val listeler = PlaylistStore.getAll(this)
        val adlar = listeler.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Silinecek listeyi sec")
            .setItems(adlar) { _, i ->
                listeler.removeAt(i)
                PlaylistStore.saveAll(this, listeler)
                val aktif = PlaylistStore.getActive(this)
                if (aktif >= listeler.size) PlaylistStore.setActive(this, 0)
                Toast.makeText(this, "Liste silindi", Toast.LENGTH_SHORT).show()
                aktifListeyiYukle()
            }
            .setNegativeButton("Iptal", null)
            .show()
    }

    private fun yeniListeDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_add_playlist, null)
        val etName = view.findViewById<EditText>(R.id.et_name)
        val rbM3u = view.findViewById<RadioButton>(R.id.rb_m3u)
        val rbXtream = view.findViewById<RadioButton>(R.id.rb_xtream)
        val etUrl = view.findViewById<EditText>(R.id.et_url)
        val llXtream = view.findViewById<LinearLayout>(R.id.ll_xtream)
        val etHost = view.findViewById<EditText>(R.id.et_host)
        val etUser = view.findViewById<EditText>(R.id.et_user)
        val etPass = view.findViewById<EditText>(R.id.et_pass)

        rbM3u.setOnCheckedChangeListener { _, secili ->
            etUrl.visibility = if (secili) View.VISIBLE else View.GONE
            llXtream.visibility = if (secili) View.GONE else View.VISIBLE
        }

        AlertDialog.Builder(this)
            .setTitle("Yeni Liste Ekle")
            .setView(view)
            .setPositiveButton("Kaydet") { _, _ ->
                val ad = etName.text.toString().trim()
                    .ifEmpty { "Liste ${PlaylistStore.getAll(this).size + 1}" }

                val yeni = if (rbXtream.isChecked) {
                    Playlist(
                        name = ad, type = "xtream",
                        host = etHost.text.toString().trim(),
                        user = etUser.text.toString().trim(),
                        pass = etPass.text.toString().trim()
                    )
                } else {
                    Playlist(name = ad, type = "m3u",
                        url = etUrl.text.toString().trim())
                }

                if (yeni.type == "m3u" && yeni.url.isEmpty()) {
                    Toast.makeText(this, "Link bos olamaz", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (yeni.type == "xtream" && yeni.host.isEmpty()) {
                    Toast.makeText(this, "Sunucu adresi bos olamaz", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val listeler = PlaylistStore.getAll(this)
                listeler.add(yeni)
                PlaylistStore.saveAll(this, listeler)
                PlaylistStore.setActive(this, listeler.size - 1)
                aktifListeyiYukle()
            }
            .setNegativeButton("Iptal", null)
            .show()
    }

    // ---------- TEK LINK OYNATMA (UNIVERSAL) ----------

    private fun linkOynatDialog() {
        val input = EditText(this).apply {
            hint = "Yayin veya liste linki yapistir"
        }
        val kutu = FrameLayout(this).apply {
            setPadding(48, 24, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Link Oynat")
            .setMessage("Her turlu linki yapistirabilirsin:\n• .m3u8 canli yayin\n• .m3u liste (gecici acilir)\n• Xtream get.php linki")
            .setView(kutu)
            .setPositiveButton("Ac") { _, _ ->
                val link = input.text.toString().trim()
                if (link.isEmpty()) return@setPositiveButton
                val listeMi = link.contains("get.php") ||
                    link.substringBefore("?").endsWith(".m3u")
                if (listeMi) {
                    title = "Gecici Liste"
                    playlistIndir(link)
                } else {
                    oynat(link, "Yayin")
                }
            }
            .setNegativeButton("Iptal", null)
            .show()
    }

    // ---------- ORTAK ----------

    private fun oynat(url: String, ad: String) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("STREAM_URL", url)
            putExtra("CHANNEL_NAME", ad)
        })
    }

    private fun playlistIndir(url: String) {
        Toast.makeText(this, "Liste yukleniyor...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val kanallar = withContext(Dispatchers.IO) {
                    M3uParser.parseFromUrl(url)
                }
                adapter.submitList(kanallar)
                Toast.makeText(
                    this@MainActivity,
                    "${kanallar.size} kanal yuklendi",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "Liste yuklenemedi: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
