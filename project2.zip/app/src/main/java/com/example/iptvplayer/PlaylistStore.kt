package com.example.iptvplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(
    val name: String,
    val type: String,          // "m3u" veya "xtream"
    val url: String = "",
    val host: String = "",
    val user: String = "",
    val pass: String = ""
) {
    // Xtream kodlarini otomatik olarak M3U linkine cevirir
    fun m3uUrl(): String {
        if (type != "xtream") return url
        var h = host.trim()
        if (!h.startsWith("http")) h = "http://$h"
        h = h.trimEnd('/')
        return "$h/get.php?username=$user&password=$pass&type=m3u_plus&output=ts"
    }
}

object PlaylistStore {
    private const val PREF = "listeler"

    fun getAll(ctx: Context): MutableList<Playlist> {
        val json = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString("data", "[]") ?: "[]"
        val arr = JSONArray(json)
        val out = mutableListOf<Playlist>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Playlist(
                    o.optString("name"), o.optString("type"), o.optString("url"),
                    o.optString("host"), o.optString("user"), o.optString("pass")
                )
            )
        }
        return out
    }

    fun saveAll(ctx: Context, list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("name", p.name).put("type", p.type).put("url", p.url)
                    .put("host", p.host).put("user", p.user).put("pass", p.pass)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString("data", arr.toString()).apply()
    }

    fun getActive(ctx: Context): Int =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("aktif", 0)

    fun setActive(ctx: Context, i: Int) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt("aktif", i).apply()
}
