package com.example.iptvplayer

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class Channel(
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String? = null
)

object M3uParser {

    fun parseFromUrl(playlistUrl: String): List<Channel> {
        val connection = URL(playlistUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 15000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "Mozilla/5.0")

        return connection.inputStream.use { stream ->
            parse(BufferedReader(InputStreamReader(stream)).readLines())
        }
    }

    fun parse(lines: List<String>): List<Channel> {
        val channels = mutableListOf<Channel>()
        var name = ""
        var logo: String? = null
        var group: String? = null

        for (rawLine in lines) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    name = line.substringAfterLast(",").trim()
                    logo = Regex("tvg-logo=\"([^\"]*)\"")
                        .find(line)?.groupValues?.get(1)
                    group = Regex("group-title=\"([^\"]*)\"")
                        .find(line)?.groupValues?.get(1)
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    if (name.isNotEmpty()) {
                        channels.add(Channel(name, line, logo, group))
                    }
                    name = ""; logo = null; group = null
                }
            }
        }
        return channels
    }
}
